package datafeed;

import java.io.IOException;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DatafeedApplication {
           
    public static void main(String[] args) {
        /***********************************************************************
        * DATABASE CONNECTION
        ***********************************************************************/        
        String customhost = args.length > 0 ? args[0] : "localhost";
        Database db = new Database(customhost);        
        Connection connection;
        
        /***********************************************************************
        * TIMEZONE (UTC)
        ***********************************************************************/
        try {
            connection = db.getConnection();
            Statement statement;
            if (connection != null)
            {
                statement = connection.createStatement();

                System.out.print("[INFO] Setting Database timezone to UTC/GMT: ");
                String query = "SET time_zone = '+00:00';";
                statement.executeUpdate(query);
                query = "SELECT NOW() AS currenttime;";
                ResultSet rs = statement.executeQuery(query);
                if (rs.first()) {
                    System.out.println(rs.getString("currenttime"));
                }            
            } else {
                System.err.println("[ERRO] Please check if database connection is valid. Exiting...");
                System.exit(1);
            }
            

            
        } catch (SQLException ex) {
            System.err.println("[NOTICE] Unable to set Time Zone on Database!");
            //Logger.getLogger(DatafeedApplication.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        /***********************************************************************
        * COUNTERLIST
        ***********************************************************************/
        CounterList counterlist = new CounterList();
        counterlist.setDatabase(db);
        counterlist.fetchCounters();                
        
        /***********************************************************************
        * START FEED SERVER
        ***********************************************************************/
        if (!counterlist.counters.isEmpty()) {
         
           DatafeedServer feedserver = new DatafeedServer(4200);                            

           while (true) {

              if (feedserver.listen())
              {
                  String line;
                  try {
                      while ((line = feedserver.read()) != null)
                      {
                       counterlist.parse(line);
                      }
                  } catch (IOException ex) {
                      System.out.println("\n[NOTICE] Feed client disconnected!");
                  }
                  finally {
                    feedserver.close();
                    feedserver.setRetry(true);
                  }
              }                     
             
           }
        }     
    }
    
}
